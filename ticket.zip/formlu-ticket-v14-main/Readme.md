License Its protected by Creative Commons CC BY-NC-SA 4.0 image
